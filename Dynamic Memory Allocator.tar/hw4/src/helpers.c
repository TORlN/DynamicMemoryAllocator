#include "helpers.h"
#include "debug.h"

/* Helper function definitions go here */
void * pagePtrs[5] = {NULL, NULL, NULL, NULL, NULL};
int maxMem = 20448;

void *getPagePtr2(int index){
    return pagePtrs[index];
}
void createPrologue(){
    ics_footer* prologue = (ics_footer*) pagePtrs[0];
    prologue->fid = FOOTER_MAGIC;
    prologue->block_size = 1;
    prologue->requested_size = 0;
    prologue++;
    return;
}

void initialPageSetup(){
    for(int i=0;i<5;i++){
        if(pagePtrs[i] == NULL){
            pagePtrs[i] = ics_get_brk();
            break;
        }
    }
    ics_inc_brk();
    return;
}

void initializeHeader(ics_free_header **head, ics_free_header ** beginSearchPtr, size_t size){   
    for(int i=1;i<5;i++){
        if(i==4){
            (*head) = pagePtrs[i];
            break;
        }else if(pagePtrs[i] == NULL){
            (*head) = pagePtrs[i-1];
            break;
        }
    }
    ics_header * temp = (ics_header*)(*head);
    if((*head) != pagePtrs[0]){
        while(temp->hid != HEADER_MAGIC){
            temp--;
        }
    }else{
        temp = (ics_header*) (*head);
        temp++;
    }
    (*head) = (ics_free_header*)temp;
    (*beginSearchPtr) = (*head);
    (*head)->header.block_size = 4080;
    ics_footer* tempFoot = (ics_footer*)(*head);
    tempFoot+=(4080/8)-1;
    while(tempFoot->fid != FOOTER_MAGIC){
        tempFoot++;
        (*head)->header.block_size +=8;
    }
    tempFoot->block_size = (*head)->header.block_size;
    (*head)->header.hid = (uint64_t)HEADER_MAGIC;
    (*head)->header.requested_size = (uint64_t)size;
    (*head)->next = NULL;
    (*head)->prev = NULL;
    return;
}

void createEpilogue(){
    ics_header* epilogue = (ics_header*) ics_get_brk();
    epilogue--;
    epilogue->hid = HEADER_MAGIC;
    epilogue->block_size = 1;
    epilogue->requested_size = 0;
    return;
}

void initializeFooter(size_t size){
    ics_footer* footer = (ics_footer*) ics_get_brk();
    footer-=2;
    footer->block_size = 4080;

    footer->fid = (uint64_t)FOOTER_MAGIC;
    footer->requested_size = (uint64_t) size;
    return;
}

bool validSize(size_t size){
    return (int)size < maxMem;
}
int setMemory(ics_free_header ** head, ics_free_header ** next, size_t size, ics_header ** returnPtr){
    ics_free_header* current = (*next);
    bool set = false;
    bool seenCurrent = false;
    int previousSize = 0;
    while(current != (*next) || seenCurrent == false){
        if(current == NULL){
            current = (*head);
            continue;
        }
        int allocatedBit = current->header.block_size;
        allocatedBit = allocatedBit & 1;
        if(allocatedBit == 0){
            if(current->header.block_size >= ((uint64_t)size+16)){
                previousSize = current->header.block_size;
                current->header.requested_size = (uint64_t)size;
                size = getMod16(size);
                int compareSize = current->header.block_size-size;
                ics_header* temp = (ics_header*)current;
                temp+=(current->header.block_size/8);
                if(compareSize == 32){
                    size +=16;
                }
                current->header.block_size = size+17;
                current->header.hid = HEADER_MAGIC;
                maxMem -= (current->header.block_size-1);
                (*returnPtr) = (ics_header*)current;
                (*returnPtr)++;
                set = true;
                break;
            }
        }
        seenCurrent = true;
        current = current->next;
    }
    if(set == false){
        return -1;
    }
    ics_free_header* nextSave = (ics_free_header*) current;
    setFooter(current, size);
    if(previousSize - (current->header.block_size-1) < MIN_BLOCK_SIZE){

        ics_header* currTemp = (ics_header*) current;
        currTemp += (current->header.block_size & -2)/8;
        if(endOfPage(currTemp)){
            if((*head) != NULL && isAllocated((*head))){
                (*head) = NULL;
                (*next) = NULL;
                return 0;
            }else{
                if(isInFreeList((*next))){
                    removeFromFreeList((*next));
                }
                (*next) = (*head);
            }
        }else{
            if(isInFreeList(current)){
                removeFromFreeList(current);
            }
            if((*next)->next != NULL){
                (*next) = (*next)->next;
            }
        }
    }else{
        (*next) = setFreeHeader(current, size, previousSize);
        (*next)->prev = nextSave->prev;
        (*next)->next = nextSave->next;
    }
    if((*next)->prev == NULL){
        (*head) = (*next);
        if((*head)->next != NULL){
            (*head)->next->prev = (*head);
        }
    }else if(freelist_head->next == NULL){
        freelist_head->next = (*next);
        (*next)->prev = freelist_head;
    }else{
        ics_free_header* freelist_head_save = (*head);
        while(freelist_head_save != NULL){
            if(freelist_head_save == (ics_free_header*)current){
                if(freelist_head_save->prev != NULL){
                    freelist_head_save->prev->next = (*next);
                }
                if(freelist_head_save->next != NULL){
                    freelist_head_save->next->prev = (*next); 
                }
                break;
            }
            freelist_head_save = freelist_head_save->next;
        }
    }
    return 0;
}
void setFooter(void * current, size_t size){
    ics_header* header = (ics_header*) current;
    current+= header->block_size-9;
    ics_footer* footer = (ics_footer*) current;
    footer->block_size = header->block_size;
    footer->fid = FOOTER_MAGIC;
    footer->requested_size = header->requested_size;
    return;
}

int requestAnotherPage(size_t size, ics_free_header* head){
    if(pagePtrs[4] != NULL){
        return -1;
    }
    for(int i=0;i<5;i++){
        if(pagePtrs[i] == NULL){
            pagePtrs[i] = ics_inc_brk();
            break;
        }
    }
    ics_header* endPtr = ics_get_brk();
    
    endPtr--;
    endPtr->block_size = 1;
    endPtr->hid = HEADER_MAGIC;
    endPtr->requested_size = 0;
    endPtr--;
    ics_footer* footer = (ics_footer*)endPtr;
    footer->fid = FOOTER_MAGIC;
    while(head->next != NULL){
        head = head->next;
    }
    head->header.block_size += 4096;
    footer->block_size = head->header.block_size;
    return 0;
}

ics_free_header* setFreeHeader(void * current, size_t size, int previousSize){
    ics_header* header = (ics_header*)current;
    ics_footer* footer = NULL;
    int blockSize = previousSize - (header->block_size-1);
    header+=(header->block_size-1)/8;
    header->block_size = (uint64_t)blockSize;
    header->hid = HEADER_MAGIC;
    header->requested_size = (uint64_t)size;
    footer = (ics_footer*)header;
    footer+=(blockSize/8)-1;
    footer->block_size = blockSize;
    return (ics_free_header*) header;
}

size_t getMod16(size_t size){
    while((int)size % 16 !=0){
        if((int)size%2 !=0){
            size+=1;
        }else{
            size+=2;
        }
    }
    return size;
}
int validPtr(void* ptr){
    void * savedPtr = ptr;
    ptr-=8;
    ics_footer * prologue = (ics_footer*) pagePtrs[0];
    ics_header * epilogue = (ics_header*) ics_get_brk();
    epilogue--;
    if(!((ics_footer*)ptr > prologue && (ics_header*)ptr < epilogue)){
        return -1;
    }
    ics_header* header = (ics_header*) ptr;
    if(header->hid != HEADER_MAGIC){
        return -1;
    }
    int bytes = (int)header->block_size;
    bytes--;
    header+=(bytes/8)-1;
    ics_footer * footer = (ics_footer*) header;
    if(footer->fid != FOOTER_MAGIC){
        return -1;
    }
    if(!(footer > prologue && (ics_header*)footer < epilogue)){
        return -1;
    }
    if(header->block_size != footer->block_size){
        return -1;
    }
    if(header->requested_size != footer->requested_size){
        return -1;
    }
    return 0;
}

int Case(void* ptr){
    ics_footer* blockBelow = (ics_footer*) ptr;
    ics_header* blockAbove = (ics_header*) ptr;
    blockBelow-=2;
    blockAbove--;
    int amountToOffset = blockAbove->block_size & -4;
    blockAbove+=amountToOffset/8;
    if(isAllocated(blockBelow)){
        return 1;
    }
    return 2;
}
bool isAllocated(void* ptr){
    ics_footer* pointer = (ics_footer*) ptr;
    int leastSigBit = pointer->block_size & 1;
    if(leastSigBit == 1){
        return true;
    }
    return false;
}
bool setNewFreelist(ics_free_header **freelist_head, ics_header** header, void* ptr){
    if((void*)(*freelist_head) > ptr){
        (*freelist_head)->prev = (ics_free_header*) (*header);
        (*freelist_head) = (ics_free_header*) (*header);
        return true;
    }
    return false;
}
ics_free_header* findPreviousFree(void* address){
    ics_free_header * saved = (ics_free_header*) address;
    ics_free_header * current = freelist_head;
    while(current != NULL){
        if(current->next > saved){
            return current;
        }
        if(current->next == NULL){
            return current;
        }
        current = current->next;
    }
    return NULL;
}
bool isInFreeList(void* address){
    ics_free_header* current = (ics_free_header*) freelist_head;
    while(current != NULL){
        if(current == (ics_free_header*) address){
            return true;
        }
        current = current->next;
    }
    return false;
}
void removeFromFreeList(void* address){
    ics_free_header* current = (ics_free_header*) freelist_head;
    while(current != NULL){
        ics_free_header* header = (ics_free_header*) address;
        if(current == header){
            if(current->prev != NULL){
                current->prev->next = current->next;
            }else{
                freelist_head = current->next;
            }
            if(current->next != NULL){
                current->next->prev = current->prev;
            }
            break;
        }
        current = current->next;
    }
    return;
}
bool endOfPage(void * address){
    int sum = ics_get_brk() - address;
    return sum <= MIN_BLOCK_SIZE;
}
bool splinterExists(void * address, size_t * size){
    ics_header* header = (ics_header*) address;
    ics_header* epiloguePtr = ics_get_brk();
    epiloguePtr--;
    header+=((*size)/8)+2;
    int counter = 0;
    if(header->hid == HEADER_MAGIC){
        return false;
    }
    for(int i=8;i<MIN_BLOCK_SIZE;i+=8){
        header++;
        counter+=8;
        if(header == epiloguePtr){
            if(counter%16 == 0){
                (*size) += counter;
            }
            return false;
        }
        if(header->hid == HEADER_MAGIC){
            return true;
        }
    }
    return false;
}

void insertIntoFreelist(void * address){
    ics_free_header* current = freelist_head;
    ics_free_header* header = (ics_free_header*) address;
    if(current == NULL){

        freelist_head = (ics_free_header*) address;
        freelist_head->next = NULL;
        freelist_head->prev = NULL;
        if(freelist_next == NULL){
            freelist_next = freelist_head;
        }
        return;
    }
    while(current != NULL){
        if(header < freelist_head){

            freelist_head->prev = header;
            header->next = freelist_head;
            freelist_head = header;
            freelist_head->prev = NULL;
            break;
        }
        if(current->next > header){
            header->prev = current;
            header->next = current->next;
            current->next = header;
            header->next->prev  = header;
            return;
        }else if(current->next == NULL){
            current->next = header;
            header->prev = current;
            header->next = NULL;
            return;
        }
        current = current->next;
    }
}