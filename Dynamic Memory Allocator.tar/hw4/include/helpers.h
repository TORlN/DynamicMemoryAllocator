#ifndef HELPERS_H
#define HELPERS_H

#include "icsmm.h"
#include <stdbool.h>

#define PAGE_SIZE 4096
#define MAX_MEM 20448
#define MIN_BLOCK_SIZE 32

/* Helper function declarations go here */

void *getPagePtr(int index);
void createPrologue();
void initialPageSetup();
void initializeHeader(ics_free_header **head, ics_free_header ** beginSearchPt, size_t size);
void createEpilogue();
void initializeFooter(size_t size);
bool validSize(size_t size);
int setMemory(ics_free_header ** head, ics_free_header ** next, size_t size, ics_header ** returnPtr);
void setFooter(void * current, size_t size);
int requestAnotherPage(size_t size, ics_free_header* head);
ics_free_header* setFreeHeader(void * current, size_t size, int previousSize);
size_t getMod16(size_t size);
int validPtr(void* ptr);
int Case(void* ptr);
bool isAllocated(void* ptr);
bool setNewFreelist(ics_free_header **freelist_head, ics_header** header, void* ptr);
ics_free_header* findPreviousFree(void* address);
bool isInFreeList(void* address);
void removeFromFreeList(void* address);
bool endOfPage(void * address);
bool splinterExists(void* address, size_t *size);
void insertIntoFreelist(void * address);
#endif
